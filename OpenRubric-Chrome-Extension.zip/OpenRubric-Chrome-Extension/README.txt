=====================================================
OpenRubric Browser Extension (Chrome / Brave / Edge)
=====================================================

HOW TO INSTALL ON ANY PC (Mac, Windows, Linux):
-----------------------------------------------------
1. Open Google Chrome, Brave, or Microsoft Edge.
2. Go to the Extensions manager:
   - In Chrome/Brave: Type `chrome://extensions` in the address bar.
   - In Edge: Type `edge://extensions` in the address bar.
3. Enable "Developer mode" using the toggle in the top-right corner.
4. Click the "Load unpacked" button in the top-left corner.
5. Select this "OpenRubric-Chrome-Extension" folder (the folder containing manifest.json).
6. OpenRubric is now installed!

HOW TO USE:
-----------------------------------------------------
- Press Cmd+Shift+M (Mac) or Ctrl+Shift+M (Windows/Linux) on any webpage or quiz.
- It will directly fetch the question, bold the correct answer on the page, and blink a small 7x7px green light in the top-left corner the number of times matching the answer option (1 blink for A, 2 for B, 3 for C, 4 for D, 5 for E).
- To configure your AI API key (Google Gemini, Groq, or Local Ollama), right-click the extension icon and select "Options", or open the popup and click the Settings gear icon.
